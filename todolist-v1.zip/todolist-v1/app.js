//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const date = require(__dirname + "/date.js");



const app = express();

let items =["Buy Food","Cook Food","Eat Food"];
// list because otherwise the the added item will replace the last item in the list
let workItems = [];
// const in javascript is different pls check sometime

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

app.get("/", function(req, res) {

let day = date.getDate();
// objects and methods from OOP
  // var currentDay = today.getDay();
  // var day = "";

  // switch (currentDay) {
  //   case 0:
  //     day = "Sunday";
  //     break;
  //   case 1:
  //     day = "Monday";
  //     break;
  //   case 2:
  //     day = "Tuesday";
  //     break;
  //   case 3:
  //     day = "Wednesday;"
  //     break;
  //   case 4:
  //     day = "Thursday;"
  //     break;
  //   case 5:
  //     day = "Friday";
  //     break;
  //   case 6:
  //     day = "Saturday";
  //     break;
  //   default:
  //   console.log("Error: current day is equal to: " + currentDay);




  res.render("list", {ListTitle: day, newListItems: items});
});


app.post("/", function(req,res){
  let item = req.body.newItem;
  // if we are writing a item in the /work page the add item to the work list else do it in the kind of day list
  if(req.body.list === "Work"){
      workItems.push(item);
      res.redirect("/work");
      // redirect to work and add the item to work list
  } else {
    items.push(item);
    res.redirect("/");
    // redirect to home (/) and add the item to the kind of day list
  }

  // redirect to the / route so that app.get gets triggered and you can get the information.
});

app.get("/work", function(req,res){
  res.render("list",{ListTitle:"Work List", newListItems: workItems});
})

app.post("/work", function(req, res){
  let item = req.body.newItem;
  workItems.push(item);
  res.redirect("/work");
})

app.get("/about", function(req, res){
  res.render("about");
})


app.listen(3000, function() {
  console.log("Server started on port 3000.");
});
